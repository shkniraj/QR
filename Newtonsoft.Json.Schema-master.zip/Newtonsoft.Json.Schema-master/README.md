# ![Logo](Doc/icons/logo.jpg) Json.NET Schema

[![NuGet version (Newtonsoft.Json.Schema)](https://img.shields.io/nuget/v/Newtonsoft.Json.Schema.svg?style=flat-square)](https://www.nuget.org/packages/Newtonsoft.Json.Schema/)
[![Build status](https://ci.appveyor.com/api/projects/status/tjanxjo47jmm36tx/branch/master?svg=true)](https://ci.appveyor.com/project/JamesNewtonKing/newtonsoft-json-schema)

- [Homepage](http://www.newtonsoft.com/jsonschema)
- [Documentation](http://www.newtonsoft.com/jsonschema/help)
- [NuGet Package](https://www.nuget.org/packages/Newtonsoft.Json.Schema)
- [Release Notes](https://github.com/JamesNK/Newtonsoft.Json.Schema/releases)
- [License](LICENSE.md)
- [Stack Overflow](https://stackoverflow.com/questions/tagged/json.net+jsonschema)
