#region License
// Copyright (c) Newtonsoft. All Rights Reserved.
// License: https://raw.github.com/JamesNK/Newtonsoft.Json.Schema/master/LICENSE.md
#endregion

using System.Reflection;
using System.Runtime.InteropServices;
using Newtonsoft.Json.Schema.Infrastructure.Licensing;

[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]

// leave unchanged for unit tests
[assembly: ReleaseDate("2014-12-27")]